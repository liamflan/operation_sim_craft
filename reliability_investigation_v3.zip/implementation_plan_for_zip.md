# Implementation Plan - Recipe Image Reliability and Semantic Match Pass

Trace and resolve image reliability issues and semantic mismatches across the Provision recipe catalog.

## User Review Required

> [!IMPORTANT]
> - I will be tracing the full image pipeline to identify why valid URLs are failing to render as placeholders.
> - I will be correcting semantic mismatches in Unsplash IDs to ensure images align with recipe content.

## Proposed Changes

### Data Layer & Logic

#### [MODIFY] [RecipeImages.ts](file:///c:/Users/liamf/.gemini/antigravity/operation_sim_craft/data/planner/RecipeImages.ts)
- Audit `UNIQUE_RECIPE_IMAGES` and remove redundant empty overrides.
- Confirm helper logic is not nullling out valid curated URLs.

#### [MODIFY] [seed.ts](file:///c:/Users/liamf/.gemini/antigravity/operation_sim_craft/data/seed.ts)
- Fix semantic mismatches for `r1`, `r2`, `r3` (Avocado Toast), `r26`, `r33`, `r40`, `r44`, and `r51`.
- Replace malformed or unreliable Unsplash IDs with high-fidelity alternatives.
- Only remove helper wrapping if tracing confirms it as the root cause of reliability issues.

#### [MODIFY] [RecipeImageAuditor.ts](file:///c:/Users/liamf/.gemini/antigravity/operation_sim_craft/data/planner/RecipeImageAuditor.ts)
- Verify if status or placeholder logic is triggering unexpected placeholders in the UI.

#### [MODIFY] [recipeRegistry.ts](file:///c:/Users/liamf/.gemini/antigravity/operation_sim_craft/data/planner/recipeRegistry.ts)
- Audit normalization flow for silent image loss.

### UI / UX Refinement

#### [MODIFY] [library.tsx](file:///c:/Users/liamf/.gemini/antigravity/operation_sim_craft/app/(tabs)/library.tsx)
- Ensure image rendering is stable and placeholders only appear for genuine data gaps.

### Debug Delivery

#### [NEW] [reliability_investigation_v3.zip](file:///c:/Users/liamf/.gemini/antigravity/operation_sim_craft/reliability_investigation_v3.zip)
- Bundling all relevant data and UI files, plus this implementation plan.

## Verification Plan

### Automated Tests
- `npm run build`

### Manual Verification
- Confirm `r1` and `r2` show images correctly.
- Confirm semantic matches for corrected IDs.
- Confirm no valid recipe falls into a placeholder silently.
