import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { StorageService } from './storage';
import { 
  NormalizedRecipe, 
  CuisineId, 
  RecipeValidationStatus
} from './planner/plannerTypes';
import { 
  curatedRoast, 
  curatedPasta, 
  highProteinSeitan, 
  highProteinTempeh, 
  highProteinHalloumi,
  highProteinTofuScramble,
  veganTikkaMasala,
  veganMeatloaf,
  veganOvernightOats,
  veganTempehBowl,
  veganOmlette,
  veggieShells,
  veggieMutterPaneer,
  veggieFetaWrap,
  pesciSeabass,
  pesciSalmonBagel
} from './planner/plannerFixtures';

// Combined Curated List
const CURATED_RECIPES: NormalizedRecipe[] = [
  curatedRoast, 
  curatedPasta, 
  highProteinSeitan, 
  highProteinTempeh, 
  highProteinHalloumi,
  highProteinTofuScramble,
  veganTikkaMasala,
  veganMeatloaf,
  veganOvernightOats,
  veganTempehBowl,
  veganOmlette,
  veggieShells,
  veggieMutterPaneer,
  veggieFetaWrap,
  pesciSeabass,
  pesciSalmonBagel
];

export type SortOption = 'protein' | 'calories' | 'time' | 'newest';

interface RecipeContextType {
  allRecipes: NormalizedRecipe[];
  curatedRecipes: NormalizedRecipe[];
  importedRecipes: NormalizedRecipe[];
  isLoading: boolean;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeCuisine: CuisineId | 'all';
  setActiveCuisine: (cuisine: CuisineId | 'all') => void;
  sortBy: SortOption;
  setSortBy: (sort: SortOption) => void;
  filteredRecipes: NormalizedRecipe[];
  importRecipe: (recipeData: Partial<NormalizedRecipe>) => Promise<void>;
  updateRecipe: (recipeId: string, updates: Partial<NormalizedRecipe>) => Promise<void>;
  deleteRecipe: (recipeId: string) => Promise<void>;
}

const STORAGE_KEY = 'provision_imported_recipes_v1';

const RecipeContext = createContext<RecipeContextType | undefined>(undefined);

export function RecipeProvider({ children }: { children: React.ReactNode }) {
  const [importedRecipes, setImportedRecipes] = useState<NormalizedRecipe[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCuisine, setActiveCuisine] = useState<CuisineId | 'all'>('all');
  const [sortBy, setSortBy] = useState<SortOption>('newest');

  // Hydrate imported recipes on mount
  useEffect(() => {
    const hydrate = async () => {
      try {
        const saved = await StorageService.getItem(STORAGE_KEY);
        if (saved) {
          setImportedRecipes(JSON.parse(saved));
        }
      } catch (err) {
        console.error('[RecipeContext] Failed to hydrate imported recipes:', err);
      } finally {
        setIsLoading(false);
      }
    };
    hydrate();
  }, []);

  // Persist imported recipes whenever they change
  useEffect(() => {
    if (!isLoading) {
      StorageService.setItem(STORAGE_KEY, JSON.stringify(importedRecipes)).catch(err => {
        console.error('[RecipeContext] Failed to save imported recipes:', err);
      });
    }
  }, [importedRecipes, isLoading]);

  const allRecipes = useMemo(() => {
    return [...CURATED_RECIPES, ...importedRecipes];
  }, [importedRecipes]);

  const filteredRecipes = useMemo(() => {
    let result = [...allRecipes];

    // 1. Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(r => 
        r.title.toLowerCase().includes(q) || 
        r.description.toLowerCase().includes(q) ||
        r.tags.some(t => t.toLowerCase().includes(q)) ||
        r.cuisineId?.toLowerCase().includes(q)
      );
    }

    // 2. Cuisine Filter
    if (activeCuisine !== 'all') {
      result = result.filter(r => r.cuisineId === activeCuisine);
    }

    // 3. Sorting
    result.sort((a, b) => {
      if (sortBy === 'protein') {
        const aP = a.macrosPerServing?.protein || 0;
        const bP = b.macrosPerServing?.protein || 0;
        return bP - aP;
      }
      if (sortBy === 'calories') {
        const aC = a.macrosPerServing?.calories || 0;
        const bC = b.macrosPerServing?.calories || 0;
        return aC - bC; // Lower calories first
      }
      if (sortBy === 'time') {
        const aT = a.totalMinutes || 0;
        const bT = b.totalMinutes || 0;
        return aT - bT; // Faster first
      }
      // 'newest' (imported first, then by internal order)
      if (a.sourceId === 'imported_user' && b.sourceId !== 'imported_user') return -1;
      if (a.sourceId !== 'imported_user' && b.sourceId === 'imported_user') return 1;
      return 0;
    });

    return result;
  }, [allRecipes, searchQuery, activeCuisine, sortBy]);

  const importRecipe = async (recipeData: Partial<NormalizedRecipe>) => {
    const newRecipe: NormalizedRecipe = {
      // Defaults for a newly imported recipe
      id: `imported_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      sourceId: 'imported_user',
      status: 'needs_human_review', // Default to review
      plannerUsable: false, // Not ready for planner until approved
      libraryVisible: true,
      macroConfidence: 0.5,
      costConfidence: 0.5,
      ingredientMappingConfidence: 0.5,
      servingConfidence: 1.0,
      normalizationWarnings: [],
      title: 'Untitled Imported Recipe',
      description: '',
      activePrepMinutes: 10,
      totalMinutes: 30,
      complexityScore: 3,
      servings: 1,
      estimatedCostTotalGBP: 0,
      estimatedCostPerServingGBP: 0,
      macrosTotal: { calories: 0, protein: 0, carbs: 0, fats: 0 },
      macrosPerServing: { calories: 0, protein: 0, carbs: 0, fats: 0 },
      ingredients: [],
      method: [],
      tags: ['New Import'],
      ingredientTags: [],
      flavourIds: [],
      styleIds: [],
      archetype: 'Staple',
      freezerFriendly: false,
      reheatsWell: true,
      yieldsLeftovers: false,
      suitableFor: ['dinner'],
      ...recipeData,
    };

    setImportedRecipes(prev => [newRecipe, ...prev]);
  };

  const updateRecipe = async (recipeId: string, updates: Partial<NormalizedRecipe>) => {
    setImportedRecipes(prev => prev.map(r => 
      r.id === recipeId ? { ...r, ...updates } : r
    ));
    // If we ever need to update curated ones (read-only), we'd handle it differently
  };

  const deleteRecipe = async (recipeId: string) => {
    setImportedRecipes(prev => prev.filter(r => r.id !== recipeId));
  };

  return (
    <RecipeContext.Provider value={{
      allRecipes,
      curatedRecipes: CURATED_RECIPES,
      importedRecipes,
      isLoading,
      searchQuery,
      setSearchQuery,
      activeCuisine,
      setActiveCuisine,
      sortBy,
      setSortBy,
      filteredRecipes,
      importRecipe,
      updateRecipe,
      deleteRecipe
    }}>
      {children}
    </RecipeContext.Provider>
  );
}

export function useRecipes() {
  const context = useContext(RecipeContext);
  if (context === undefined) {
    throw new Error('useRecipes must be used within a RecipeProvider');
  }
  return context;
}
