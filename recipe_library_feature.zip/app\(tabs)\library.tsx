import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, StyleSheet, Platform, useWindowDimensions } from 'react-native';
import { useRecipes, SortOption } from '../../data/RecipeContext';
import { FontAwesome5 } from '@expo/vector-icons';
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';
import { NormalizedRecipe, CuisineId } from '../../data/planner/plannerTypes';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import ImportRecipeModal from '../../components/ImportRecipeModal';

const CUISINES: { id: CuisineId | 'all'; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'italian', label: 'Italian' },
  { id: 'mexican', label: 'Mexican' },
  { id: 'japanese', label: 'Japanese' },
  { id: 'mediterranean', label: 'Mediterranean' },
];

const SORT_OPTIONS: { id: SortOption; label: string; icon: string }[] = [
  { id: 'newest', label: 'Newest', icon: 'clock' },
  { id: 'protein', label: 'Protein', icon: 'dumbbell' },
  { id: 'calories', label: 'Calories', icon: 'leaf' },
  { id: 'time', label: 'Faster', icon: 'bolt' },
];

export default function RecipeLibrary() {
  const { 
    filteredRecipes, 
    searchQuery, 
    setSearchQuery, 
    activeCuisine, 
    setActiveCuisine,
    sortBy,
    setSortBy
  } = useRecipes();
  const colorScheme = useColorScheme();
  const { width } = useWindowDimensions();
  const router = useRouter();
  const [importModalVisible, setImportModalVisible] = useState(false);
  
  const isDesktop = width >= 768;
  const isDarkMode = colorScheme === 'dark';

  return (
    <View style={[styles.container, isDarkMode && styles.containerDark]}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header Section */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.title, isDarkMode && styles.textWhite]}>Recipe Library</Text>
            <Text style={[styles.subtitle, isDarkMode && styles.textMuted]}>
              Browse Provision classics and your imported collection.
            </Text>
          </View>
          
          <TouchableOpacity 
            activeOpacity={0.8}
            onPress={() => setImportModalVisible(true)}
            style={styles.importBtn}
          >
            <FontAwesome5 name="plus" size={12} color="white" style={{ marginRight: 8 }} />
            <Text style={styles.importBtnText}>Import Recipe</Text>
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={[styles.searchContainer, isDarkMode && styles.searchContainerDark]}>
          <View style={styles.searchIcon}>
            <FontAwesome5 name="search" size={14} color={isDarkMode ? '#8C9A90' : '#888'} />
          </View>
          <TextInput
            placeholder="Search all recipes, cuisines, or tags..."
            placeholderTextColor={isDarkMode ? '#555' : '#999'}
            style={[styles.searchInput, isDarkMode && styles.textWhite]}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => setSearchQuery('')} style={styles.clearBtn}>
              <FontAwesome5 name="times-circle" size={14} color="#BBB" />
            </TouchableOpacity>
          )}
        </View>

        {/* Filter & Sort Bar */}
        <View style={styles.filterSortRow}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterScroll}>
            {CUISINES.map(c => (
              <TouchableOpacity 
                key={c.id} 
                onPress={() => setActiveCuisine(c.id)}
                style={[
                  styles.filterChip, 
                  activeCuisine === c.id && styles.filterChipActive,
                  isDarkMode && styles.filterChipDark,
                  isDarkMode && activeCuisine === c.id && styles.filterChipActiveDark
                ]}
              >
                <Text style={[
                  styles.filterChipText, 
                  activeCuisine === c.id && styles.filterChipTextActive,
                  isDarkMode && styles.filterChipTextDark
                ]}>
                  {c.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <View style={[styles.divider, isDarkMode && styles.dividerDark]} />

          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.sortScroll}>
            {SORT_OPTIONS.map(s => (
              <TouchableOpacity 
                key={s.id} 
                onPress={() => setSortBy(s.id)}
                style={[
                  styles.sortChip, 
                  sortBy === s.id && styles.sortChipActive,
                  isDarkMode && styles.sortChipDark,
                  isDarkMode && sortBy === s.id && styles.sortChipActiveDark
                ]}
              >
                <FontAwesome5 
                  name={s.icon} 
                  size={10} 
                  color={sortBy === s.id ? '#FFF' : (isDarkMode ? '#8C9A90' : '#6A766E')} 
                  style={{ marginRight: 6 }} 
                />
                <Text style={[
                  styles.sortChipText, 
                  sortBy === s.id && styles.sortChipTextActive,
                  isDarkMode && styles.sortChipTextDark
                ]}>
                  {s.label}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Recipe Grid */}
        <View style={styles.grid}>
          {filteredRecipes.length > 0 ? (
            filteredRecipes.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} isDesktop={isDesktop} isDarkMode={isDarkMode} />
            ))
          ) : (
            <View style={styles.emptyState}>
              <View style={[styles.emptyIconContainer, isDarkMode && styles.emptyIconContainerDark]}>
                <FontAwesome5 name="search" size={32} color={isDarkMode ? '#333' : '#EEE'} />
              </View>
              <Text style={[styles.emptyText, isDarkMode && styles.textWhite]}>No recipes match your search.</Text>
              <Text style={styles.emptySubtext}>Try adjusting your filters or importing something new.</Text>
              <TouchableOpacity 
                onPress={() => {
                  setSearchQuery('');
                  setActiveCuisine('all');
                }}
                style={styles.resetBtn}
              >
                <Text style={styles.resetBtnText}>Clear all filters</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>

      <ImportRecipeModal
        visible={importModalVisible}
        onClose={() => setImportModalVisible(false)}
      />
    </View>
  );
}

function RecipeCard({ recipe, isDesktop, isDarkMode }: { recipe: NormalizedRecipe, isDesktop: boolean, isDarkMode: boolean }) {
  const router = useRouter();

  return (
    <TouchableOpacity 
      activeOpacity={0.9}
      onPress={() => router.push(`/recipe/${recipe.id}`)}
      style={[
        styles.card, 
        isDarkMode && styles.cardDark,
        { width: isDesktop ? '31%' : '100%' }
      ]}
    >
      <View style={styles.imageContainer}>
        {recipe.imageUrl ? (
          <Image source={recipe.imageUrl} style={styles.image} contentFit="cover" transition={200} />
        ) : (
          <View style={styles.placeholderImage}>
            <FontAwesome5 name="utensils" size={24} color={isDarkMode ? '#333' : '#DDD'} />
          </View>
        )}
        
        {/* Badges */}
        <View style={styles.badgeRow}>
          <View style={[styles.sourceBadge, recipe.sourceId === 'imported_user' ? styles.sourceImported : styles.sourceCurated]}>
            <Text style={[styles.sourceBadgeText, recipe.sourceId === 'imported_user' && { color: '#FFF' }]}>
              {recipe.sourceId === 'imported_user' ? 'IMPORTED' : 'PROVISION'}
            </Text>
          </View>
          {recipe.status !== 'approved' && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusBadgeText}>{recipe.status.toUpperCase().replace('_', ' ')}</Text>
            </View>
          )}
        </View>
      </View>

      <View style={styles.cardInfo}>
        <Text numberOfLines={1} style={[styles.cardTitle, isDarkMode && styles.textWhite]}>
          {recipe.title}
        </Text>
        
        <View style={styles.metaRow}>
          <View style={styles.metaItem}>
            <FontAwesome5 name="clock" size={10} color="#888" style={{ marginRight: 4 }} />
            <Text style={styles.metaText}>{recipe.totalMinutes}m</Text>
          </View>
          {recipe.cuisineId && (
            <View style={styles.metaItem}>
              <Text style={styles.metaText}>{recipe.cuisineId.charAt(0).toUpperCase() + recipe.cuisineId.slice(1)}</Text>
            </View>
          )}
          <View style={styles.metaItem}>
            <Text style={styles.metaText}>{recipe.macrosPerServing?.protein || 0}g P</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FBFCF8' },
  containerDark: { backgroundColor: '#141A17' },
  scrollContent: { paddingHorizontal: 32, paddingBottom: 100, paddingTop: 40 },
  header: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'flex-start',
    marginBottom: 40 
  },
  title: { fontSize: 32, fontWeight: '700', color: '#1B251F', letterSpacing: -1 },
  subtitle: { fontSize: 16, color: '#6A766E', marginTop: 4 },
  textWhite: { color: '#FFF' },
  textMuted: { color: '#8C9A90' },
  
  importBtn: {
    backgroundColor: '#7BA96A',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#7BA96A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4
  },
  importBtnText: { color: 'white', fontWeight: '700', fontSize: 14 },

  searchContainer: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#FFF', 
    borderRadius: 24, 
    borderWidth: 1, 
    borderColor: 'rgba(0,0,0,0.05)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.02,
    shadowRadius: 10,
    marginBottom: 24,
    height: 60
  },
  searchContainerDark: { 
    backgroundColor: '#1E2622', 
    borderColor: 'rgba(255,255,255,0.05)' 
  },
  searchIcon: { paddingLeft: 24, paddingRight: 12 },
  searchInput: { 
    flex: 1, 
    height: '100%', 
    fontSize: 16, 
    fontWeight: '400' 
  },
  clearBtn: { paddingRight: 20 },

  filterSortRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 32,
    gap: 16
  },
  filterScroll: { gap: 8 },
  sortScroll: { gap: 8 },
  divider: { width: 1, height: 24, backgroundColor: '#EEE' },
  dividerDark: { backgroundColor: '#333' },

  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.05)'
  },
  filterChipDark: { backgroundColor: '#1E2622', borderColor: 'rgba(255,255,255,0.05)' },
  filterChipActive: { backgroundColor: '#7BA96A', borderColor: '#7BA96A' },
  filterChipActiveDark: { backgroundColor: '#7BA96A', borderColor: '#7BA96A' },
  filterChipText: { fontSize: 13, fontWeight: '600', color: '#6A766E' },
  filterChipTextDark: { color: '#8C9A90' },
  filterChipTextActive: { color: '#FFF' },

  sortChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: 'rgba(0,0,0,0.02)'
  },
  sortChipDark: { backgroundColor: 'rgba(255,255,255,0.03)' },
  sortChipActive: { backgroundColor: '#1B251F' },
  sortChipActiveDark: { backgroundColor: '#FFF' },
  sortChipText: { fontSize: 12, fontWeight: '700', color: '#6A766E', textTransform: 'uppercase', letterSpacing: 0.5 },
  sortChipTextDark: { color: '#8C9A90' },
  sortChipTextActive: { color: '#FFF' },
  sortChipTextActiveDark: { color: '#1B251F' },
  
  grid: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    gap: 24,
    justifyContent: 'flex-start'
  },
  card: { 
    backgroundColor: '#FFF', 
    borderRadius: 24, 
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.04,
    shadowRadius: 12,
    elevation: 3,
    marginBottom: 8
  },
  cardDark: { 
    backgroundColor: '#1E2622',
  },
  imageContainer: { height: 180, backgroundColor: '#F0F2ED', position: 'relative' },
  image: { width: '100%', height: '100%' },
  placeholderImage: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  
  badgeRow: { 
    position: 'absolute', 
    top: 16, 
    left: 16, 
    right: 16, 
    flexDirection: 'row', 
    justifyContent: 'space-between' 
  },
  sourceBadge: { 
    paddingHorizontal: 10, 
    paddingVertical: 5, 
    borderRadius: 8, 
    backgroundColor: 'rgba(255,255,255,0.9)'
  },
  sourceImported: { backgroundColor: '#7BA96A' },
  sourceCurated: { backgroundColor: 'rgba(255, 255, 255, 0.9)' },
  sourceBadgeText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.5, color: '#1B251F' },
  
  statusBadge: { 
    paddingHorizontal: 10, 
    paddingVertical: 5, 
    borderRadius: 8, 
    backgroundColor: 'rgba(239, 68, 68, 0.9)' 
  },
  statusBadgeText: { fontSize: 9, fontWeight: '800', color: '#FFF', letterSpacing: 0.5 },
  
  cardInfo: { padding: 20 },
  cardTitle: { fontSize: 17, fontWeight: '600', color: '#1B251F', marginBottom: 8 },
  metaRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 12 },
  metaItem: { flexDirection: 'row', alignItems: 'center' },
  metaText: { fontSize: 12, color: '#888', fontWeight: '500' },
  
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingVertical: 100, width: '100%' },
  emptyIconContainer: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#F7F8F5', alignItems: 'center', justifyContent: 'center', marginBottom: 24 },
  emptyIconContainerDark: { backgroundColor: '#1E2622' },
  emptyText: { fontSize: 20, fontWeight: '700', color: '#1B251F', marginBottom: 8 },
  emptySubtext: { fontSize: 15, color: '#6A766E', marginBottom: 24, textAlign: 'center' },
  resetBtn: { paddingHorizontal: 20, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#7BA96A' },
  resetBtnText: { color: '#7BA96A', fontWeight: '700', fontSize: 14 }
});
