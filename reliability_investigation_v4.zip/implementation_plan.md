# Implementation Plan - Recipe Image Reliability and Semantic Match Pass

Trace and resolve image reliability issues and semantic mismatches across the Provision recipe catalog.

## User Review Required

> [!IMPORTANT]
> - I will implement the user-provided state-based error handling in `library.tsx` to prevent "blank slabs".
> - I will normalize legacy recipes in `recipeRegistry.ts` using the refined logic to ensure truthy image IDs.
> - I will update `seed.ts` with accurate semantic mappings for the core curated set.

## Proposed Changes

### Data Layer & Logic

#### [MODIFY] [RecipeImages.ts](file:///c:/Users/liamf/../../data/planner/RecipeImages.ts)
- Audit `UNIQUE_RECIPE_IMAGES` and ensure it doesn't nullify valid URLs.

#### [MODIFY] [seed.ts](file:///c:/Users/liamf/../../data/seed.ts)
- Update Unsplash IDs for semantic correctness:
  - `r1` (Salmon Bowl) -> `photo-1467003909585-2f8a72700288`
  - `r2` (Steak) -> `photo-1600891964092-4316c288032e`
  - `r3` (Avocado Toast) -> `photo-1525351484163-7529414344d8`
  - `r26` (Fried Rice), `r33` (Lentil Curry), `r40` (Chilli), `r44` (Chicken), `r51`.
- Clean up malformed URLs.

#### [MODIFY] [recipeRegistry.ts](file:///c:/Users/liamf/../../data/planner/recipeRegistry.ts)
- Implement refined normalization logic that ensures `imageUrl` is resolved at definition time.
- Re-map `FULL_RECIPE_CATALOG` to ensure `getRecipeImage` is context-aware.

### UI / UX Refinement

#### [MODIFY] [library.tsx](file:///c:/Users/liamf/../../app/(tabs)/library.tsx)
- Implement `hasImageError` state in `RecipeCard`.
- Ensure placeholder (icon + text) is rendered behind the image or as a fallback.
- Defensive metadata handling (protein/cuisine fallbacks).

### Debug Delivery

#### [NEW] [reliability_investigation_v4.zip](file:///c:/Users/liamf/../../reliability_investigation_v4.zip)
- Bundling all relevant data and UI files.

## Verification Plan

### Automated Tests
- `npm run build`

### Manual Verification
- Confirm Salmon and Steak images render.
- Confirm Avocado Toast visual match.
- Confirm failed loads show the full placeholder design (not blank).
