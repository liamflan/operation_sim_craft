# Recipe Library: Consistency & Trust-Model Pass

I have tightened the Recipe Library and Import flow to ensure a consistent status model and a trustworthy planner integration.

## Key Improvements

### 1. Unified Status Model
The application now uses a consistent three-tier status model across all layers:
- **Ready**: High-fidelity, fully reviewed recipes.
- **Needs Review**: Default for new imports requiring validation.
- **Draft**: Work-in-progress imports.

### 2. Planner Trust Enforcement
Imported recipes are now **strictly held** from the planner until they are marked as `ready`.
- `plannerUsable` is now a reactive flag that strictly follows `status === 'ready'`.
- This ensures your automated meal plans only include high-quality, verified data.

### 3. Logic-Gated Imports
The `Mark as Ready` action in the import flow is now gated:
- You can only mark a recipe as ready if it has a **Title**, **Calories**, and **Protein**.
- This prevents "empty" or partial data from degrading your nutrition tracking.

### 4. Product-Native Language
Removed "AI-demo" terminology in favor of calm, clinical product states:
- "Provision is thinking..." ➔ **"Extracting recipe..."**
- "Analyzing content..." ➔ **"Parsing content..."**

### 5. Defensive UI
The Library search, filtering, and grid rendering have been hardened:
- Added defensive guards for metadata fields like tags, macros, and descriptions.
- The library remains stable even if imported data is incomplete or corrupted.

## Verification
- [x] **Build Check**: Successful internal build and route export.
- [x] **Planner Gating**: Verified code-level enforcement of `plannerUsable`.
- [x] **UI Resilience**: Verified no crashes with partial metadata.

---
*The Recipe Library is now structurally solid and ready for reliable planner integration.*
